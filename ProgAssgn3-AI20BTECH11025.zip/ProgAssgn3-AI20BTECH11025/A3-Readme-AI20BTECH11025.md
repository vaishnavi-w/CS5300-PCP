AI20BTECH11025 - W VAISHNAVI

- There are 5 files in the folder
    - MRMW-AI20BTECH11025.cpp
    - InbuiltMRMW-AI20BTECH11025.cpp
    - A3-Readme-AI20BTECH11025.txt
    - A3-Report-AI20BTECH11025.pdf
    - inp-params.txt

Executing the file:

- Command line for compiling in GCC:

$ g++ MRMW-AI20BTECH11025.c -o MRMW-AI20BTECH11025

- Exectuable file fo the name MRMW-AI20BTECH11025 is created in the directory
- Command line for running the executable

$ ./MRMW-AI20BTECH11025 < inp-params.txt

- The values in input files can be modified according to the user.
- Similarly, it can be done for InbuiltMRMW-AI20BTECH11025
- Output is given in log files
