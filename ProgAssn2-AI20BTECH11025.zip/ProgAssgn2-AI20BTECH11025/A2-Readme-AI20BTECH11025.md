AI20BTECH11025 - W VAISHNAVI

- There are 5 files in the folder
    - CLQ-Src-AI20BTECH11025.cpp
    - NLQ-Src-AI20BTECH11025.cpp
    - A2-Readme-AI20BTECH11025.txt
    - A2-Report-AI20BTECH11025.pdf
    - inp-params.txt

Executing the file:

- Command line for compiling in GCC:

$ g++ CLQ-Src-AI20BTECH11025.c -o CLQ-A2-AI20BTECH11025

- Exectuable file fo the name CLQ-A2-AI20BTECH11025 is created in the directory
- Command line for running the executable

$ ./CLQ-A2-AI20BTECH11025 <inp-params.txt

- The values in input files can be modified according to the user.
- Similarly, it can be done for NLQ-A2-AI20BTECH11025
- Output is given in log files, two files CLQ-out.txt and NLQ-out.txt have the average runtimes for deq, enq and all operations for each thread seperated by spaces. 