#include <iostream>
#include <vector>
#include <thread>
#include <mutex>
#include <queue>
#include <chrono>
#include <random>
#include <fstream>
#include <atomic>

using namespace std;

// Define constants for queue capacity
const int MAX_CAPACITY = 2000;

// Define vectors for storing times for threads
vector<long long> thrTimes_enq(32, 0);
vector<long long> thrTimes_deq(32, 0);
vector<long long> thrTimes(32, 0);

vector<int> num_enq(32, 0);
vector<int> num_deq(32, 0);

long long time_deq, time_enq, time_total;
int n_deq, n_enq;

// To sample a random number from exp distribution
double random_expo(double lambda){
    double u = rand()/(RAND_MAX + 1.0);
    return -log(1 - u)/lambda;
}

// Calculate average times
void computeStats(int n, int numOps)
{
    time_deq = 0, time_enq = 0, time_total = 0;
    n_deq = 0, n_enq = 0;

    for(int i = 0; i < n; i++)
    {
        time_deq += thrTimes_deq[i];
        time_enq += thrTimes_enq[i];

        n_deq += num_deq[i];
        n_enq += num_enq[i];

        thrTimes[i] = (thrTimes_deq[i] + thrTimes_enq[i])/numOps;
        if(num_deq[i] > 0) thrTimes_deq[i] = thrTimes_deq[i]/num_deq[i];
        if(num_enq[i] > 0) thrTimes_enq[i] = thrTimes_enq[i]/num_enq[i];
    }
    time_total = (time_deq + time_enq)/(n * numOps);
    if(n_deq > 0) time_deq /= n_deq;
    if(n_enq > 0) time_enq /= n_enq;
}

// Define the HWQueue structure
struct HWQueue
{
    atomic <int> tail;
    vector<atomic<int>> items;
    HWQueue() : tail(0), items(2000) {}
};

// Enqueue
void enq(HWQueue& queue, int x) 
{
    int i = queue.tail.fetch_add(1, std::memory_order_relaxed);
    queue.items[i].store(x, std::memory_order_relaxed);
}

// Dequeue 
int deq(HWQueue& queue){
    while (true) {
        int range = queue.tail.load(std::memory_order_relaxed);
        for (int i = 0; i < range; i++) {
            int value = queue.items[i].exchange(-1, std::memory_order_relaxed);
            if (value != -1) {
                return value;
            }
        }
    }
}

void testThread(HWQueue& clq, int n, int numOps, double lambda, double rndLt) 
{
    double uniformVal, sleepTime;
    std::chrono::time_point<std::chrono::high_resolution_clock> startTime, endTime;

    int v;

    for (int i = 0; i < numOps; i++){
        double p = (double) rand()/RAND_MAX;

        if (p < rndLt){ // Enqueue case 
            v = rand(); // Enqueue some random value

            startTime = std::chrono::high_resolution_clock::now();
            enq(clq, v);
            endTime = std::chrono::high_resolution_clock::now();
            thrTimes_enq[i % n] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
            num_enq[i%n]++;
        } 
        else { // Dequeue case 
            startTime = std::chrono::high_resolution_clock::now();
            v = deq(clq);
            endTime = std::chrono::high_resolution_clock::now();
            thrTimes_deq[i % n] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
            num_deq[i%n]++;
        }

        sleepTime = random_expo(lambda);
        std::this_thread::sleep_for(std::chrono::nanoseconds(static_cast<long long>(sleepTime * 1e9)));
    }
}

int main() 
{
    int n, numOps;
    double lambda, rndLt;

    // Take input n and m
    ifstream inputfile("inp-params.txt");
    inputfile >> n >> numOps >> lambda >> rndLt;
    inputfile.close();

    long long time_deqq, time_enqq, time_totalq;

    time_deqq = 0;
    time_enqq = 0;
    time_totalq = 0;

    for(int iter = 1; iter <= 1; iter++)
    {
        for (int i = 0; i < 32; i++) thrTimes_enq[i] = 0; 
        for (int i = 0; i < 32; i++) thrTimes_deq[i] = 0; 
        for (int i = 0; i < 32; i++) thrTimes[i] = 0; 

        for (int i = 0; i < 32; i++) num_enq[i] = 0; 
        for (int i = 0; i < 32; i++) num_deq[i] = 0; 

        HWQueue q;
        
        // Queue initialization
        for (int i = 0; i < MAX_CAPACITY; i++) {
            q.items[i].store(-1);
        }
        q.tail.store(0, std::memory_order_relaxed);

        thread t[n];

        for (int i = 0; i < n; i++) {
            t[i] = thread(testThread, ref(q), n, numOps, lambda, rndLt);
        }

        for (int i = 0; i < n; i++) {
            t[i].join();
        }

        // Compute and print statistics here
        computeStats(n, numOps);

        time_deqq += time_deq;
        time_enqq += time_enq;
        time_totalq += time_total;
    }

    time_totalq /= 5;
    double throughput = 1000000/time_totalq;
    // cout << "Time taken : " << time_totalq << " Throughput : " << throughput << endl;

    // Write outputs to file
    ofstream outputfile_NLQ("NLQ-out.txt");

    outputfile_NLQ << "Deque" << endl;
    for(int i = 0; i < n; i++)
        outputfile_NLQ << thrTimes_deq[i] << " ";

    outputfile_NLQ << endl << "Enque" << endl;
    for(int i = 0; i < n; i++)
        outputfile_NLQ << thrTimes_enq[i] << " ";

    outputfile_NLQ << endl << "Total Time" << endl;
    for(int i = 0; i < n; i++)
        outputfile_NLQ << thrTimes[i] << " ";

    outputfile_NLQ.close();

    return 0;
}
