#include <iostream>
#include <bits/stdc++.h>
#include <math.h>
#include <vector>
#include <thread>

using namespace std;

atomic <int> counter(3); // Using a shared counter for DAM1 starting from 3
vector<vector<int>> primes_SAM1; // Vector of vectors to store prime numbers for each thread
vector<vector<int>> primes_DAM1; // Vector of vectors to store prime numbers for each thread

bool isprime(int n) 
{
    if (n == 1) return false;
    if (n == 2) return true;

    for (int i = 2; i * i <= n; i++)
        if (n % i == 0) return false;

    return true;
}

// Static Allocation Method1
void SAM1(int threadId, int m, int N) 
{
    vector<int> threadPrimes; // Local vector to store prime numbers for the current thread

    for (int i = threadId*2 + 3; i <= N; i += 2*m) 
    {
        if (isprime(i)) threadPrimes.push_back(i); // Store prime numbers in the local vector
    }

    // Write the local vector of prime numbers for the current thread to global prime list
    primes_SAM1[threadId] = threadPrimes;
}

// Dynamic Allocation Method1
void DAM1(int threadId, int N)
{
    vector<int> threadPrimes; // Local vector to store prime numbers for the current thread

    for(int i = counter.fetch_add(10); i < N; i = counter.fetch_add(10))
    {
        for(int j = i; j < i + 10; j+=2)
        {
            if(isprime(j)) threadPrimes.push_back(j); // Store prime numbers in the local vector
        }
    }

    // Write the local vector of prime numbers for the current thread to global prime list
    primes_DAM1[threadId] = threadPrimes;
}


int main() 
{
    int n, m;

    // Take input n and m
    ifstream inputfile("inp-params.txt");
    inputfile >> n >> m;
    inputfile.close();
    
    int N = (int)pow(10, n);

    long long time1 = 0, time2 = 0;
    
    // SAM1
    for(int iter = 1; iter < 6; iter++)
    {
        primes_SAM1.clear();
        primes_SAM1.resize(m); // Initialize the vector of vectors

        thread t[m];

        auto start = std::chrono::high_resolution_clock::now(); // To check time

        for (int i = 0; i < m; i++) {
            t[i] = thread(SAM1, i, m, N);
        }

        for (int i = 0; i < m; i++) {
            t[i].join();
        }

        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
        time1 += duration;
    }

    // Combine the prime numbers from all threads into a single vector
    vector<int> combinedPrimes_SAM1;
    combinedPrimes_SAM1.push_back(2);
    for (int i = 0; i < m; i++) {
        combinedPrimes_SAM1.insert(combinedPrimes_SAM1.end(), primes_SAM1[i].begin(), primes_SAM1[i].end());
    }

    // Sort the prime numbers in the vector
    sort(combinedPrimes_SAM1.begin(), combinedPrimes_SAM1.end());

    // Write primes to file
    ofstream outputfile_SAM1("Primes-SAM1.txt");

    for (int prime : combinedPrimes_SAM1)
        outputfile_SAM1 << prime << " ";

    outputfile_SAM1.close();
    
    /*------------------------------------------------------------------------------------------------------------------------------*/
    
    // DAM1
    for(int iter = 1; iter < 6; iter++)
    {
        counter.store(3);
        primes_DAM1.clear();
        primes_DAM1.resize(m); // Initialize the vector of vectors

        thread t[m];

        auto start = std::chrono::high_resolution_clock::now(); // To check time

        for (int i = 0; i < m; i++) {
            t[i] = thread(DAM1, i, N);
        }

        for (int i = 0; i < m; i++) {
            t[i].join();
        }

        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
        time2 += duration;
    }

    // Combine the prime numbers from all threads into a single vector
    vector<int> combinedPrimes_DAM1;
    combinedPrimes_DAM1.push_back(2);
    for (int i = 0; i < m; i++) {
        combinedPrimes_DAM1.insert(combinedPrimes_DAM1.end(), primes_DAM1[i].begin(), primes_DAM1[i].end());
    }

    // Sort the prime numbers in the vector
    sort(combinedPrimes_DAM1.begin(), combinedPrimes_DAM1.end());

    // Write primes to file
    ofstream outputfile_DAM1("Primes-DAM1.txt");

    for (int prime : combinedPrimes_DAM1)
        outputfile_DAM1 << prime << " ";

    outputfile_DAM1.close();

    // Writing times
    ofstream times("Times.txt");
    
    times << time1 << " " << time2 << " microseconds" << endl;

    times.close();
}
