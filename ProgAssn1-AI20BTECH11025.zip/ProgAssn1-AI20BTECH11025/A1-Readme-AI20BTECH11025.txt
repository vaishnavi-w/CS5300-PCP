AI20BTECH11025 - W VAISHNAVI

- There are 4 files in the folder
    - A1-Src-AI20BTECH11025.cpp
    - A1-Readme-AI20BTECH11025.txt
    - A1-Report-AI20BTECH11025.pdf
    - inp-params.txt

Executing the file:

- Command line for compiling in GCC:

$ g++ A1-Src-AI20BTECH11025.c -o A1-AI20BTECH11025

- Exectuable file fo the name A1-AI20BTECH11025 is created in the directory
- Command line for running the executable

$ ./A1-AI20BTECH11025 <inp-params.txt

- The value of n and m can be modified according to the user.
- Output is given in log files, two files Primes-SAM1.txt and Primes-DAM1.txt are created having primes seperated by spaces.
